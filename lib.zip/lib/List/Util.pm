# List::Util.pm
#
# Copyright (c) 1997-2001 Graham Barr <gbarr@pobox.com>. All rights reserved.
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.

package List::Util;

require Exporter;
require DynaLoader;

our @ISA       = qw(Exporter DynaLoader);
our @EXPORT_OK = qw(first min max minstr maxstr reduce sum shuffle);
our $VERSION   = "1.07_00";
our $XS_VERSION = $VERSION;
$VERSION = eval $VERSION;

bootstrap List::Util $XS_VERSION;

1;

__END__

